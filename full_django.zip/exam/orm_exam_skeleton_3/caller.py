import os
import django

from main_app.models import Book, Borrower

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()


# Import your models here
# Create and run your queries within functions

def get_books_by_author(search_author: str = None):
    if search_author is None:
        return ''

    books = Book.objects.filter(author__icontains=search_author).order_by('published_date')

    if books.exists():
        final = []
        for b in books:
            final.append(
                f'Title: {b.title}, Author: {b.author}, Published Date: {b.published_date}, Available: {b.is_available}')

        return '\n'.join(final)

    else:
        return ''


def get_recent_borrowers():
    borrowers = Borrower.objects.order_by('-registration_date')
    if borrowers.exists():
        borrowers = borrowers[:5]
        final = [f'Full Name: {b.full_name}, Email: {b.email}, Phone Number: {b.phone_number}, Registration Date: {b.registration_date}' for b in borrowers]
        return '\n'.join(final)
    else:
        return ''


def update_availability_status():
    books = Book.objects.filter(published_date__year__lt=2000, is_available=True)

    if books.exists():
        books.update(is_available=False)
        return f'Availability status updated for {len(books)} books.'

    else:
        return 'No books updated.'
