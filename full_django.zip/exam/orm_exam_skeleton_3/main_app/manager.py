from django.db import models


class BookCustomManager(models.Manager):
    def get_available_books(self):
        return self.filter(is_available=True).order_by('-published_date')
