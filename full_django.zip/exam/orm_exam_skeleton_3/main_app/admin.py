from django.contrib import admin

from main_app.models import Book, Borrower


# Register your models here.

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'published_date', 'is_available']
    list_filter = ['genre', 'is_available']
    search_fields = ['author', 'title']


@admin.register(Borrower)
class BorrowerAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'email', 'phone_number', 'registration_date']
    list_filter = ['registration_date']
    search_fields = ['email', 'full_name']
