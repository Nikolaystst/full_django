from django.db import models

from main_app import admin
from main_app.admin import BookAdmin, BorrowerAdmin
from main_app.manager import BookCustomManager


# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=100)
    published_date = models.DateField()
    genre = models.CharField(max_length=50)
    is_available = models.BooleanField(default=True)

    objects = BookCustomManager()


class Borrower(models.Model):
    full_name = models.CharField(max_length=150)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    registration_date = models.DateTimeField(auto_now_add=True)

# admin.site.register(Book, BookAdmin)
# admin.site.register(Borrower, BorrowerAdmin)
