import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Author, Article, Review
from django.db.models import Q, Count, Max, Avg


# Import your models here
# Create and run your queries within functions


def get_authors(search_name: str = None, search_email: str = None):
    q_1 = Q()

    if search_name is None and search_email is None:
        return ''

    if search_name is not None:
        q_1 &= Q(full_name__icontains=search_name)

    if search_email is not None:
        q_1 &= Q(email__icontains=search_email)

    authors = Author.objects.filter(q_1).order_by('-full_name')

    if authors.exists():
        return '\n'.join(
            f'Author: {a.full_name}, email: {a.email}, status: {"Banned" if a.is_banned else "Not Banned"}' for a in
            authors)

    else:
        return ''


def get_top_publisher():
    author = Author.objects.annotate(cnt_art=Count('articles')).filter(cnt_art__gt=0).order_by('-cnt_art', 'email')

    if author.exists():
        author = author.first()
        return f"Top Author: {author.full_name} with {author.cnt_art} published articles."

    else:
        return ''


def get_top_reviewer():
    author = Author.objects.annotate(cnt_art=Count('reviews')).filter(cnt_art__gt=0).order_by('-cnt_art', 'email')


    if author.exists():
        author = author.first()
        return f"Top Reviewer: {author.full_name} with {author.cnt_art} published reviews."

    else:
        return ''


def get_latest_article():
    art = Article.objects.annotate(num_rev=Count('reviews_2'), avg_rat=Avg('reviews_2__rating')).order_by(
        'published_on')

    if art.exists():
        l_art = art.last()

        authors = ', '.join(a.full_name for a in l_art.authors.all().order_by('full_name'))
        avg_rate = l_art.avg_rat or 0
        art_title = l_art.title
        num_of_rews = l_art.num_rev

        return (f"The latest article is: {art_title}."
                f" Authors: {authors}."
                f" Reviewed: {num_of_rews} times. Average Rating: {avg_rate:.2f}.")

    else:
        return ''





def get_top_rated_article():
    top_article = Article.objects.annotate(avg_rating=Avg('reviews_2__rating'),
                                           num_reviews=Count('reviews_2')).filter(num_reviews__gt=0).order_by(
        '-avg_rating', 'title').first()

    if top_article:
        return f"The top-rated article is: {top_article.title}, with an average rating of {top_article.avg_rating:.2f}, reviewed {top_article.num_reviews} times."
    else:
        return ""


def ban_author(email=None):
    if email is None:
        return "No authors banned."

    try:
        author = Author.objects.prefetch_related('reviews').get(email__exact=email, is_banned=False)
    except Author.DoesNotExist:
        return "No authors banned."

    num_reviews = author.reviews.count()

    if author is not None:
        author.is_banned = True
        author.reviews.all().delete()
        author.save()
        return f"Author: {author.full_name} is banned! {num_reviews} reviews deleted."
    else:
        return "No authors banned."
