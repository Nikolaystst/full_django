import os
import django
from django.db.models import Q, Count, F

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
# Create and run your queries within functions

from main_app.models import Profile, Product, Order


# from populate import populate_model_with_data
#
# populate_model_with_data(Profile)
# populate_model_with_data(Product)
# populate_model_with_data(Order)

# print(Profile.objects.get_regular_customers())


def get_profiles(search_string: str = None):
    if search_string is None:
        return ''
    query = Q(full_name__icontains=search_string) | Q(email__icontains=search_string) | Q(
        phone_number__icontains=search_string)
    objects = Profile.objects.filter(query).order_by('full_name')

    # if not objects:
    #     return ''

    return '\n'.join(f'Profile: {o.full_name}, email: {o.email},'
                     f' phone number: {o.phone_number}, orders: {o.orders.count()}'
                     for o in objects)


def get_loyal_profiles():
    objects = Profile.objects.annotate(count_ord=Count('orders')).filter(count_ord__gt=2).order_by('-count_ord')
    if not objects:
        return ''
    final = [f'Profile: {o.full_name}, orders: {o.count_ord}' for o in objects]
    return '\n'.join(final)


def get_last_sold_products():
    obj = Order.objects.prefetch_related('products').last()
    if not obj or not obj.products.all():
        return ''

    products = ', '.join(p.name for p in obj.products.all())
    return f'Last sold products: {products}'


# print(get_profiles('Profile'))
# print(get_loyal_profiles())
# print(get_last_sold_products())

def get_top_products():
    products = Product.objects.annotate(count_ord=Count('order')).filter(count_ord__gt=0).order_by('-count_ord',
                                                                                                   'name')[0:5]
    final = ["Top products:"]

    if not products or products is None:
        return ''

    for p in products:
        final.append(f'{p.name}, sold {p.count_ord} times')

    return '\n'.join(final)


def apply_discounts():
    orders = (Order.objects.annotate(count_products=Count('products')).filter(count_products__gt=2, is_completed=False)
              .update(total_price=F('total_price') * 0.9))

    return f"Discount applied to {orders} orders."


def complete_order():
    ord_1 = Order.objects.prefetch_related('products').filter(is_completed=False).first()
    if not ord_1 or ord_1 is None:
        return ''

    for product in ord_1.products.all():
        product.in_stock -= 1
        if product.in_stock == 0:
            product.is_available = False
        product.save()
    ord_1.is_completed = True
    ord_1.save()
    return "Order has been completed!"


# print(get_top_products())
# print(apply_discounts())
# print(complete_order())
