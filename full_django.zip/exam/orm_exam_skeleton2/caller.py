import os

import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Movie, Actor, Director
from django.db.models import Q, Count, Avg, F
from decimal import Decimal


# from populate import populate_model_with_data
#
# # Import your models here
# # Create and run your queries within functions
#
# populate_model_with_data(Director)
# populate_model_with_data(Actor)
# populate_model_with_data(Movie)
# print(Director.objects.get_directors_by_movies_count())

def get_directors(search_name: str = None, search_nationality: str = None):
    q_1 = Q()
    final = []
    if search_name is None and search_nationality is None:
        return ''

    if search_name is not None:
        q_1 &= Q(full_name__icontains=search_name)

    if search_nationality is not None:
        q_1 &= Q(nationality__icontains=search_nationality)

    directors = Director.objects.filter(q_1).order_by('full_name')
    if directors.exists():
        for d_1 in directors:
            final.append(
                f'Director: {d_1.full_name}, nationality: {d_1.nationality}, experience: {d_1.years_of_experience}')

        return '\n'.join(final)
    else:
        return ''


def get_top_director():
    director = Director.objects.annotate(count_movie=Count('movie')).order_by('-count_movie', 'full_name').first()
    if not director or director is None:
        return ''

    return f'Top Director: {director.full_name}, movies: {director.count_movie}.'


def get_top_actor():
    starring_actor_1 = Actor.objects.filter(hehe__starring_actor__isnull=False).annotate(count_movies=Count(
        'hehe__starring_actor')).order_by('-count_movies', 'full_name')

    if starring_actor_1.exists():
        starring_actor = starring_actor_1[0]
        movies = starring_actor.hehe.all()
        average_rt = movies.aggregate(avg_rate=Avg('rating'))['avg_rate']
        movie_titles = [f'{m.title}' for m in movies]
        return (f"Top Actor: {starring_actor.full_name}, starring in movies: "
                f"{', '.join(movie_titles)},"
                f" movies average rating: {average_rt:.1f}")
    else:
        return ''


def get_actors_by_movies_count():
    actors = Actor.objects.filter(movie__isnull=False).annotate(cnt_movies=Count('movie')).order_by(
        '-cnt_movies', 'full_name'
    )[0:3]

    if actors.exists():
        # a = actors[0:3]
        return '\n'.join(f"{b.full_name}, participated in {b.cnt_movies} movies" for b in actors)
    else:
        return ''


def get_top_rated_awarded_movie():
    movie = Movie.objects.filter(is_awarded=True).order_by('-rating', 'title')

    if movie.exists():
        the_movie = movie.first()
        actor = the_movie.starring_actor.full_name if the_movie.starring_actor else 'N/A'
        # if actor is None:
        #     actor = 'N/A'
        actors = the_movie.actors.order_by('full_name')
        actors_final = [a.full_name for a in actors]

        return f"Top rated awarded movie: {the_movie.title}, rating: {the_movie.rating:.1f}. Starring actor: {actor}. Cast: {', '.join(actors_final)}."

    else:
        return ''


# print(get_top_rated_awarded_movie())

def increase_rating():
    movies = Movie.objects.filter(is_classic=True, rating__lte=9.9)

    if movies.exists():
        movies.update(rating=F('rating') + 0.1)

        return f'Rating increased for {len(movies)} movies.'

    else:
        return 'No ratings increased.'


print(increase_rating())
