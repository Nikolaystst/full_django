import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from django.db.models import Q, Count, F
# from populate import populate_model_with_data
from main_app.models import Director, Actor, Movie


# Import your models here
# Create and run your queries within functions

def get_directors(search_name: str = None, search_nationality: str = None):
    q_1 = Q()

    if search_name is None and search_nationality is None:
        return ''

    if search_name is not None:
        q_1 &= Q(full_name__icontains=search_name)

    if search_nationality is not None:
        q_1 &= Q(nationality__icontains=search_nationality)

    directors = Director.objects.filter(q_1).order_by('full_name')
    if directors.exists():
        return '\n'.join(
            f'Director: {d.full_name}, nationality: {d.nationality}, experience: {d.years_of_experience}' for d in
            directors)

    else:
        return ''


# print(get_directors('Director'))

def get_top_director():
    director = Director.objects.annotate(cnt_mv=Count('movies_2')).filter(cnt_mv__gt=0).order_by('-cnt_mv', 'full_name')

    if director.exists():
        director = director.first()
        return f"Top Director: {director.full_name}, movies: {director.cnt_mv}."

    else:
        return ''


# print(get_top_director())

def get_top_actor():
    actor = Actor.objects.annotate(cnt_mv=Count('star')).filter(cnt_mv__gt=0).order_by('-cnt_mv', 'full_name')

    if actor.exists():
        actor = actor.first()
        movies = []
        rate = 0
        all_movies = 0
        for movie in actor.star.all():
            movies.append(movie.title)
            rate += movie.rating
            all_movies += 1

        return f"Top Actor: {actor.full_name}, starring in movies: {', '.join(movies)}, movies average rating: {(rate / all_movies):.1f}"

    else:
        return ''


# print(get_top_actor())

def get_actors_by_movies_count():
    actors = Actor.objects.annotate(cnt_mv=Count('movies')).filter(cnt_mv__gt=0).order_by('-cnt_mv', 'full_name')
    if actors.exists():
        actors = actors[:3]
        return '\n'.join(f'{a.full_name}, participated in {a.cnt_mv} movies' for a in actors)

    else:
        return ''


# print(get_actors_by_movies_count())

def get_top_rated_awarded_movie():
    movies = Movie.objects.filter(is_awarded=True).order_by('-rating', 'title')

    if movies.exists():
        movie = movies.first()
        return (f"Top rated awarded movie: {movie.title}, rating: {movie.rating}."
                f" Starring actor: {movie.starring_actor.full_name if movie.starring_actor else 'N/A'}. Cast:"
                f" {', '.join(a.full_name for a in movie.actors.all())}.")

    else:
        return ''


# print(get_top_rated_awarded_movie())


def increase_rating():
    movies = Movie.objects.filter(is_classic=True, rating__lt=10.0)
    if movies.exists():
        final = f"Rating increased for {len(movies)} movies."
        movies.update(rating=F('rating') + 0.1)
        return final

    else:
        return "No ratings increased."


# print(increase_rating())
