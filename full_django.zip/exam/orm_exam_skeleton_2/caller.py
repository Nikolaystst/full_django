import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Order, Product, Profile
from django.db.models import Q, Count, F


# from populate import populate_model_with_data

# Import your models here
# Create and run your queries within functions
# populate_model_with_data(Profile)
# populate_model_with_data(Product)
# populate_model_with_data(Order)

# print(Profile.objects.get_regular_customers())

def get_profiles(search_string: str = None):
    if search_string is None:
        return ''

    q_1 = Q(full_name__icontains=search_string) | Q(email__icontains=search_string) | Q(
        phone_number__icontains=search_string)

    profiles = Profile.objects.filter(q_1).order_by('full_name')
    if profiles.exists():
        final = []
        for p in profiles:
            final.append(
                f'Profile: {p.full_name}, email: {p.email}, phone number: {p.phone_number}, orders: {p.order_set.count()}')
        return '\n'.join(final)

    else:
        return ''


# print(get_profiles('profile'))


def get_loyal_profiles():
    profiles = Profile.objects.annotate(profile_order=Count('order')).filter(profile_order__gt=2).order_by(
        '-profile_order')
    if profiles.exists():
        final = []
        for p in profiles:
            final.append(f'Profile: {p.full_name}, orders: {p.profile_order}')
        return '\n'.join(final)

    else:
        return ''


# print(get_loyal_profiles())


def get_last_sold_products():
    order = Order.objects.prefetch_related('products').last()
    if not order or order is None:
        return ''
    products = order.products.all().order_by('name')
    if not products or products is None:
        return ''
    final = [p.name for p in products]
    return f'Last sold products: {", ".join(final)}'


# print(get_last_sold_products())

def get_top_products():
    products = Product.objects.annotate(cnt_ord=Count('order')).filter(cnt_ord__gt=0).order_by('-cnt_ord', 'name')
    if products.exists():
        final = ['Top products:']
        products = products[:5]
        for p in products:
            final.append(f'{p.name}, sold {p.cnt_ord} times')

        return '\n'.join(final)

    else:
        return ''


# print(get_top_products())

def apply_discounts():
    ords = Order.objects.annotate(cnt_prd=Count('products')).filter(cnt_prd__gt=2, is_completed=False)
    if ords.exists():
        ords.update(total_price=F('total_price') * 0.9)
        return f"Discount applied to {len(ords)} orders."
    else:
        return "Discount applied to 0 orders."


# print(apply_discounts())


def complete_order():
    ord_1 = Order.objects.filter(is_completed=False).prefetch_related('products')

    if ord_1.exists():
        ord_1 = ord_1.first()
        for p in ord_1.products.all():
            p.in_stock -= 1
            if p.in_stock == 0:
                p.is_available = False
            p.save()
        ord_1.is_completed = True
        ord_1.save()
        return "Order has been completed!"

    else:
        return ''


# print(complete_order())
