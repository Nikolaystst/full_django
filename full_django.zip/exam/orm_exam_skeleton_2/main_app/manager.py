from django.db import models
from django.db.models import Count


class CustomProfile(models.Manager):
    def get_regular_customers(self):
        return self.annotate(profile_order=Count('order')).filter(profile_order__gt=2).order_by('-profile_order')