import os
import django
from django.db.models import F

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Pet, Artifact, Location, Car, Task, HotelRoom, Character


# Import your models here

# Create queries within functions

def create_pet(name: str, species: str):
    pet = Pet.objects.create(name=name, species=species)
    return pet.__str__()


def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool):
    art = Artifact.objects.create(name=name, origin=origin, age=age, description=description, is_magical=is_magical)
    return art.__str__()


def delete_all_artifacts():
    Artifact.objects.all().delete()


def show_all_locations():
    locations = Location.objects.all().order_by('-id')
    return '\n'.join(str(loc) for loc in locations)


def new_capital():
    Location.objects.filter(pk=1).update(is_capital=True)


def get_capitals():
    return Location.objects.all().filter(is_capital=True).values('name')


def delete_first_location():
    Location.objects.first().delete()


def apply_discount():
    cars = Car.objects.all()

    for car in cars:
        disc = 1 - (sum(int(x) for x in str(car.year)) / 100)
        car.price_with_discount = float(car.price) * disc

    Car.objects.bulk_update(cars, ['price_with_discount'])


def get_recent_cars():
    return Car.objects.all().filter(year__gte=2020).values('model', 'price_with_discount')


def delete_last_car():
    Car.objects.last().delete()


def show_unfinished_tasks():
    tasks = Task.objects.filter(is_finished=False)
    return "\n".join(str(t) for t in tasks)


def complete_odd_tasks():
    tasks = Task.objects.all()
    for task in tasks:
        if task.id % 2 != 0:
            task.is_finished = True

    Task.objects.bulk_update(tasks, ["is_finished"])


def encode_and_replace(text: str, task_title: str):
    tasks = Task.objects.all().filter(title=task_title)
    decode = ''.join(chr(ord(x) - 3) for x in text)

    for task in tasks:
        task.description = decode

    Task.objects.bulk_update(tasks, ['description'])


def get_deluxe_rooms():
    rooms = HotelRoom.objects.all().filter(room_type='Deluxe')
    return '\n'.join(str(x) for x in rooms if x.id % 2 == 0)


def increase_room_capacity():
    rooms = HotelRoom.objects.all().order_by('id')
    capacity_of_prev_room = 0

    for room in rooms:
        if not room.is_reserved:
            continue

        if capacity_of_prev_room == 0:
            room.capacity = room.capacity + room.id
        else:
            room.capacity += capacity_of_prev_room

        capacity_of_prev_room = room.capacity

    HotelRoom.objects.bulk_update(rooms, ['capacity'])


def reserve_first_room():
    h = HotelRoom.objects.first()
    h.is_reserved = True
    h.save()


def delete_last_room():
    HotelRoom.objects.last().delete()


def update_characters() -> None:
    Character.objects.filter(class_name='Mage').update(
        level=F('level') + 3,
        intelligence=F('intelligence') - 7
    )

    Character.objects.filter(class_name='Warrior').update(
        hit_points=F('hit_points') / 2,
        dexterity=F('dexterity') + 4,
    )

    Character.objects.filter(class_name__in=["Assassin", "Scout"]).update(
        inventory="The inventory is empty",
    )


def fuse_characters(first_character: Character, second_character: Character):
    fuse_name = first_character.name + ' ' + second_character.name
    fuse_class_name = 'Fusion'
    fuse_level = (first_character.level + second_character.level) // 2
    fuse_strength = (first_character.strength + second_character.strength) * 1.2
    fuse_dexterity = (first_character.dexterity + second_character.dexterity) * 1.4
    fuse_intelligence = (first_character.intelligence + second_character.intelligence) * 1.5
    fuse_hit_points = first_character.hit_points + second_character.hit_points
    if first_character.class_name in ["Mage", "Scout"]:
        fuse_inventory = "Bow of the Elven Lords, Amulet of Eternal Wisdom"
    else:
        fuse_inventory = "Dragon Scale Armor, Excalibur"

    Character.objects.create(name=fuse_name, class_name=fuse_class_name, level=fuse_level, strength=fuse_strength,
                             dexterity=fuse_dexterity, intelligence=fuse_intelligence, hit_points=fuse_hit_points,
                             inventory=fuse_inventory)

    first_character.delete()
    second_character.delete()


def grand_dexterity():
    Character.objects.update(dexterity=30)


def grand_intelligence():
    Character.objects.update(intelligence=40)


def grand_strength():
    Character.objects.update(strength=50)


def delete_characters():
    Character.objects.filter(inventory="The inventory is empty").delete()
