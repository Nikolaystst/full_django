import os

import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from datetime import timedelta, date
from django.db.models import Sum, Count
from main_app.models import Author, Book, Artist, Song, Product, Review, DrivingLicense, Driver, Owner, Registration, \
    Car


# Create queries within functions

# def show_all_authors_with_their_books():
#     final = []
#     authors = Author.objects.all().order_by('id')
#
#     for author in authors:
#         to_append = []
#         books = author.book_set.all()
#
#         if not books:
#             continue
#
#         to_append = ', '.join(book.title for book in books)
#         final.append(f'{author.name} has written - {to_append}')
#
#     return '\n'.join(final)


def show_all_authors_with_their_books():
    authors = Author.objects.prefetch_related('book_set').order_by('id')
    final = []

    for author in authors:
        books = author.book_set.all()

        if not books:
            continue

        books_apend = ', '.join(book.title for book in books)
        final.append(f"{author.name} has written - {books_apend}!")
    return '\n'.join(final)


def delete_all_authors_without_books():
    Author.objects.filter(book__isnull=True).delete()


def add_song_to_artist(artist_name: str, song_title: str):
    artist = Artist.objects.get(name=artist_name)
    song = Song.objects.get(title=song_title)
    artist.songs.add(song)


def get_songs_by_artist(artist_name: str):
    return Artist.objects.get(name=artist_name).songs.order_by('-id')


def remove_song_from_artist(artist_name: str, song_title: str):
    artist = Artist.objects.get(name=artist_name)
    song = Song.objects.get(title=song_title)
    artist.songs.remove(song)


def calculate_average_rating_for_product_by_name(product_name: str):
    # product = Product.objects.get(name=product_name)
    # reviews = product.reviews.all()
    # sum_1 = sum(review.rating for review in reviews)
    # sum_1 /= len(reviews)
    # return sum_1

    pro_1 = Product.objects.annotate(sum_1=Sum('reviews__rating'), count_1=Count('reviews')).get(name=product_name)
    return pro_1.sum_1 / pro_1.count_1


def get_reviews_with_high_ratings(threshold: int):
    return Review.objects.filter(rating__gte=threshold)


def get_products_with_no_reviews():
    return Product.objects.filter(reviews__isnull=True).order_by('-name')


def delete_products_without_reviews():
    Product.objects.filter(reviews__isnull=True).delete()


def calculate_licenses_expiration_dates():
    licenses = DrivingLicense.objects.order_by('-license_number')
    final = []
    for licens in licenses:
        expiration_date = licens.issue_date + timedelta(days=365)
        final.append(f'License with id: {licens.license_number} expires on {expiration_date}!')

    return '\n'.join(final)


def get_drivers_with_expired_licenses(due_date):
    expiration_date = due_date - timedelta(days=365)
    return Driver.objects.filter(drivinglicense__issue_date__gt=expiration_date)


def register_car_by_owner(owner: Owner):
    registration = Registration.objects.filter(car__isnull=True).first()
    car = Car.objects.filter(registration__isnull=True).first()

    car.owner = owner
    car.registration = registration
    car.save()

    registration.car = car
    registration.registration_date = date.today()
    registration.save()

    return f"Successfully registered {car.model} to {owner.name} with registration number {registration.registration_number}."
