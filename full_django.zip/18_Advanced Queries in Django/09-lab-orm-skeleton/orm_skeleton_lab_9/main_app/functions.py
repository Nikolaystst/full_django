from django.db import models
from django.db.models import Sum, Q, F

from main_app.models import Order, Product


def product_quantity_ordered():
    orders = Product.objects.annotate(total_sum=Sum('orderproduct__quantity')).exclude(
        total_sum=None
    ).order_by('-total_sum')
    final = []

    for order in orders:
        final.append(f'Quantity ordered of {order.name}: {order.total_sum}')

    return '\n'.join(final)


def ordered_products_per_customer():
    final = []
    prefetched = Order.objects.prefetch_related('orderproduct_set__product__category').order_by('id')

    for order in prefetched:
        final.append(f'Order ID: {order.id}, Customer: {order.customer.username}')
        for products in order.orderproduct_set.all():
            final.append(f'- Product: {products.product.name}, Category: {products.product.category.name}')

    return '\n'.join(final)


def filter_products():
    products = Product.objects.filter(Q(is_available=True) & Q(price__gt=3)).order_by('-price', 'name')
    final = []
    for p in products:
        final.append(f'{p.name}: {p.price}lv.')

    return '\n'.join(final)


def give_discount():
    products = Product.objects.filter(Q(is_available=True) & Q(price__gt=3)).update(price=(F('price') * 0.7))
    products = Product.objects.filter(Q(is_available=True)).order_by('-price', 'name')
    final = []
    for p in products:
        final.append(f'{p.name}: {p.price}lv.')

    return '\n'.join(final)
